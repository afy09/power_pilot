<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\power_pilot\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>